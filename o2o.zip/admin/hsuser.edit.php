<?php
include("../includes/init.php");
$id = $_GET['id'];
$row = $Db->get_one("hsuser","id=$id");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>角色管理</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="css/zzstyle.css">
<script src="js/jquery-1.9.1.min.js"></script>
<script src="js/Validform_v5.3.2.js"></script>
</head>
<body>
<div id="wrap">
  <div class="tab">
    <ul>
      <li><a href="user.inc.php">管理员管理</a></li>
      <li><a href="javascript:;" class="on">添加管理员</a></li>
      <li><a href="user.edit.inc.php">修改密码</a></li>
    </ul>
  </div>
  <div class="main">
    <fieldset>
      <legend>操作提示</legend>
      1：角色名称不能为空；
    </fieldset>
    <form action="hsuser_check.php" method="post" name="myform" class="demoform">     
     <table cellspacing="0" class="sub">
        <tr>
		  <td width="100" align="right">用户名：</td>
		  <td><input type="text" readonly name="username" id="username" size="20" value="<?php echo $row['username']?>" />
			<td> </td>
		</tr> <tr>
          <td width="100" align="right">真实姓名：</td>
          <td><input type="text" name="name" value="<?php echo $row['name']?>" size="20" />
            <td> </td>
        </tr>
        <tr>
          <td width="100" align="right">身份证号：</td>
          <td><input type="text" name="idcard" id="idcard" size="20" value="<?php echo $row['idcard']?>" />
            <td> </td>
        </tr>
        <tr>
          <td width="100" align="right">星级：</td>
          <td><input type="text" name="star" id="star" size="20" value="<?php echo $row['star']?>" />
          </td>
          <td></td>
        </tr>
        <tr>
          <td width="100" align="right">电话：</td>
          <td><input type="text" name="tel" id="tel" size="20" value="<?php echo $row['tel']?>" />
          <td> </td>
        </tr>
        <tr>
          <td width="100" align="right">是否空闲：</td>
       		<td><input type="radio" name="isfree" value="是" <?php if($row['isfree']=="是"){echo "checked";}?>>是
				<input type="radio" name="isfree" value="否" <?php if($row['isfree']=="否"){echo "checked";}?>>否
            <td> </td>
        </tr>
        <tr class="bg2">
          <td></td>
          <td><input type="submit" class="button"  value="提交修改" />
            <input type="reset" class="button" value="取消返回" />
            <input type="hidden" name="action" value="edit" />
            <input type="hidden" name="gid" value="<?php echo $id?>" />
            </td>
        </tr>
      </table>
    </form>
  </div>
</div>
<script>
		var vf = $(".demoform").Validform({
			tiptype:2,
			datatype:{
				"zh2-4":/^[\w\W]{2,10}$/,
				"idcard":/^\d{8,18}|[0-9x]{8,18}|[0-9X]{8,18}?$/,
				"star":/^([0-9][0-9]*)+(.[0-9]{1})?$/
			}
		});

		vf.addRule(
		[
			{
				ele:"[name=name]",
				datatype:"zh2-4",
				nullmsg:"密码不能为空！",
				sucmsg:"符合标准！", 
				errormsg:"真实姓名为2-4位汉字！"
			},
			{
				ele:"[name=idcard]",
				datatype:"idcard",
				sucmsg:"符合标准！", 
			},
			{
				ele:"[name=star]",
				datatype:"star", 
				sucmsg:"符合标准！", 
				
				errormsg:"请填写带一位小数点的数字！", 
			},
			{
				"ele":"[name=tel]",
				sucmsg:"符合标准！", 
				"datatype":"m",
				errormsg:"手机号格式不符，请输入正确手机号"
			},
			
			{
				"ele":"[name=isfree]",
				sucmsg:"符合标准！",
				"datatype":"*",
				nullmsg:"请选择是否空闲"
			},
		]
		);
</script>
</body>
</html>