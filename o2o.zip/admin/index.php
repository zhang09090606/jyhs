<?php include("../includes/reg.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />

<link rel="icon" href="favicon.ico" type="image/x-icon" />

<title>追风者管理后台</title>

</head>

<frameset rows="96,*,31" frameborder="no" border="0" framespacing="0">

  <frame src="index.top.php" noresize="noresize" id="topFrame" frameborder="0" name="topFrame" marginwidth="0" marginheight="0" scrolling="no">

<frameset rows="*" cols="210,*" id="frame" framespacing="0" frameborder="no" border="0">

	  <frame src="index.left.php" name="leftFrame" id="leftFrame" noresize="noresize" marginwidth="0" marginheight="0" frameborder="0" scrolling="yes">

    <frame src="index.main.php" name="main" id="main" marginwidth="0" marginheight="0" frameborder="0" scrolling="yes">

	</frameset>

	<frame src="index.bottom.php" noresize="noresize" id="bottomFrame" frameborder="0" name="bottomFrame" marginwidth="0" marginheight="0" scrolling="no">

<noframes>

  <body>当前浏览器不支持框架!</body>

</noframes>

</frameset>

</html>

