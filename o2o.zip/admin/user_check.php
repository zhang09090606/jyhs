<?php
include("../includes/init.php");
$action = $_REQUEST['action'];
$add_url = "user.add.php";
switch($action)
{
    case"add";
        $name = $_POST['name'];
        $pwd = $_POST['pwd'];
		$sex=$_POST['sex'];
		$tel = $_POST['tel'];
		$nickname = $_POST['nickname']; 
		$point = $_POST['point'];
		$isadd=$_POST['isadd'];
		$ishsuser=$_POST['ishsuser'];
        //查询新添加的账号是否存在数据表中
        $row = $Db->get_one("user","name='$name'");
        if($row){
            $Db->back_info("账号已存在",$add_url);
        }
		$data=array(
           	'name'=>$name,
			'pwd'=>$pwd,
			'sex'=>$sex,
			'tel'=>$tel,
			'nickname'=>$nickname,
			'point'=>$point,
			'isadd'=>$isadd,
			'ishsuser'=>$ishsuser
         );
			$Db->insertdata("user",$data);
			msg_url("添加成功","user.inc.php");
        break;	

    case"del";
        $id = $_GET['id'];
        $Db->deletedata("user","id=$id");
        msg_url("删除成功","user.inc.php");
        break;
    case"edit";
        $id = $_POST['gid'];
        $pwd = !empty($_POST['pwd'])? trim($_POST['pwd']):"";
		$repwd = !empty($_POST['repwd'])? trim($_POST['repwd']):"";
        $old_pwd = !empty($_POST['old_pwd'])? trim($_POST['old_pwd']):"";
        if(empty($pwd) && empty($repwd) ){
            $pwds = $old_pwd;
        }elseif($pwd == $repwd){
            $pwds = $pwd;//要修改的密码
        }else{
            $Db->back_info("俩次密码不一致","admin.edit.php?id=$id");
        }
        $data = ['pw8d'=>$pwds];
        //print_r($data);die;
        $Db->updatedata("admin",$data,"id=$id");
        msg_url("修改成功","admin.inc.php");
        break;
}