<?php
include('../includes/init.php');
$id = $_GET['id'];
$row = $Db->get_one("waste","id=$id");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>菜单管理</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="css/zzstyle.css">
<script src="js/jquery-1.9.1.min.js"></script>
<script src="js/Validform_v5.3.2.js"></script>
</head>
<body>
<div id="wrap">
  <div class="tab">
    <ul>
      <li><a href="menu.inc.php">菜单管理</a></li>
      <li><a href="javascript:;" class="on">编辑菜单</a></li>     
    </ul>
  </div>
  <div class="main">
    <fieldset>
      <legend>操作提示</legend>
      1：菜单名称不能为空；
    </fieldset>
    <form action="menu_check.php" method="post" name="myform" class="demoform" enctype="multipart/form-data">     
      <table cellspacing="0" class="sub">
        <tr>
          <td width="100" align="right">选择分类：</td>
          <td>
          <select name="parentid" id="parentid">
          <option value="$row['class']">
             <?php if($row['class']!=0){echo $row['name'];}else{echo "一级分类";}?>
          </option>
              <option value="0">一级分类</option>
              <?php
			  $str=$Db->get_all("waste","class=0");
              foreach($str as $v){
              ?>
              <option value="<?php echo $v['id']?>"><?php echo $v['name']?></option>
              <?php
              }
              ?>
          </select>
          </td>
        </tr>
        <tr>
          <td width="100" align="right">废品名称：</td>
          <td><input   name="name" type="text" id="name" value="<?php echo $row['name']?>" size="20" /></td>
           <td></td>
        </tr>
        <tr>
          <td width="100" align="right">废品价格：</td>
          <td><input type="text" name="price" id="password" size="20" value="<?php echo $row['price']?>" /></td>
          <td></td>
        </tr>
        <tr>
          <td width="100" align="right">废品备注信息：</td>
          <td><input   name="inf" type="text" id="inf" size="20" value="<?php echo $row['inf']?>" /></td>
           <td></td>
        </tr>
        <tr>
          <td width="100" align="right">废品图片：</td>
            <td width="100"> <input type="file" name="file" id="file" value="上传图片" /></td>
            <td></td>
        </tr>
        <tr class="bg2">
          <td></td>
          <td><input type="submit" class="button"  value="修改管理" />
            <input type="reset" class="button" value="取消返回" />
            <input type="hidden" name="action" value="edit" />
            <input type="hidden" name="gid" value="<?php echo $row['id']?>" />
          </td>
        </tr>
      </table>
    </form>
  </div>
</div>
<script>
		var vf = $(".demoform").Validform({
			tiptype:2,
			datatype:{
				"zh2-4":/^[\u4E00-\u9FA5\uf900-\ufa2d]{2,4}$/,
				"*1-16":/^[\w\W]{1,16}$/,
				"price":/^(\d{1,10}|\d{1,7}\.\d{1,2)$/,
				"*1-50":/^[\w\W]{0,50}$/,
				"*1-11":/^[\w\W]{1,11}$/,
				"isfile":function CheckWorkFile(){
				var file=document.getElementById("file").value;
				if(file.length<1){
					return "请选择图片";
				}
				var filepath = $("input[name='file']").val();
                var extStart = filepath.lastIndexOf(".");
                var ext = filepath.substring(extStart, filepath.length).toUpperCase();
                if (ext != ".BMP" && ext != ".PNG" && ext != ".GIF" && ext != ".JPG" && ext != ".JPEG") {     
                    return "图片限于bmp,png,gif,jpeg,jpg格式";
                }
            	 var fileSize =  document.getElementById('file').files[0];
				if(fileSize.size>1048576){
					return "图片大小不符合标准最大不超过1MB";
				}		
				}
			}
			
		});

		vf.addRule(
		[
			{
				ele:"[name=name]",
				datatype:"*1-16", 
				nullmsg:"物品不能为空！",
				sucmsg:"符合标准！", 
				errormsg:"物品为1-16个任意字符！", 
				tip:"请填写物品名称",
				altercss:"hui" 
			},
			{
				ele:"[name=price]",
				datatype:"price",
			
				errormsg:"价格整数部分为7位以内数字，小数部分最多两位小数！",
				nullmsg:"价格不能为空！",
			},
			{
				ele:"[name=inf]",
				datatype:"*0-50",
				errormsg:"价格为0-50位的任意字符",
			},
			{
				ele:"[name=file]",
				datatype:"isfile",
			},
		]
		);
</script>
</body>
</html>