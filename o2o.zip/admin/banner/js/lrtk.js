// ad
function dy(code)
{
var ojs='<script type="text/javascript" src="http://cbjs.baidu.com/js/o.js"></script>';
if (code=="top210x90_1"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "288992";</script>');
document.write(ojs);}
if (code=="top210x90_2"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "288996";</script>');
document.write(ojs);}
if (code=="top728x90"){
document.writeln("<script type=\"text\/javascript\"><!--");
document.writeln("google_ad_client = \"ca-pub-4213001413639273\";");
document.writeln("\/* 全站_顶部_728x90 *\/");
document.writeln("google_ad_slot = \"4539245504\";");
document.writeln("google_ad_width = 728;");
document.writeln("google_ad_height = 90;");
document.writeln("\/\/-->");
document.writeln("<\/script>");
document.writeln("<script type=\"text\/javascript\" src=\"http:\/\/pagead2.googlesyndication.com\/pagead\/show_ads.js\"><\/script>")
}
if (code=="gg300x250_1"){//85849 GOOGLE
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "85851";</script>');
document.write(ojs);}
if (code=="gg300x250_2"){//85851 BAIDU
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "85849";</script>');
document.write(ojs);}
if (code=="gg160x600"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "85858";</script>');
document.write(ojs);}
if (code=="lb728x90_1"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "372923";</script>');
document.write(ojs);}
if (code=="lb728x90_2"){//377258 baidu
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "377258";</script>');
document.write(ojs);}
if (code=="lb336x280"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "85856";</script>');
document.write(ojs);}
if (code=="ny300x250"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "85859";</script>');
document.write(ojs);}
if (code=="ny728x90"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "85865";</script>');
document.write(ojs);}
if (code=="js852x90_1"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "416044";</script>');
document.write(ojs);}
if (code=="in852x90_1"){//289000 baidu
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "288997";</script>');
document.write(ojs);}
if (code=="in852x90_2"){//288997 GOOGLE
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "289000";</script>');
document.write(ojs);}
if (code=="in300x90_1"){//289003
document.write('<a href="/show/" target="_blank"><img src="/images/300x90-01.jpg" width="300" height="90" /></a>');}
if (code=="in300x90_2"){//289007
document.write('<a href="/zt/book/" target="_blank"><img src="/images/300x90-02.jpg" width="300" height="90" /></a>');}
if (code=="in300x250"){
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "289013";</script>');
document.write(ojs);}
if (code=="widget"){// widget 
document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "409341";</script>');
document.write(ojs);}
if (code=="yulu"){// 语录
document.writeln("设计语录：");
tips = new Array(50);
tips[0] = '比喻强过道理，平凡朴素比阳春白雪更容易让人理解。';
tips[1] = '通过内容展示个性，而不是通过虚饰展示个性。——Facebook Timeline';
tips[2] = '人的接受能力和精力是有限的，给用户一个重点，就是帮助用户节约时间和成本。全是重点等于没有重点。';
tips[3] = '漂亮但无内容的网站，没有人会第三次访问它。';
tips[4] = '所谓策划：简单的问题复杂化，复杂的问题简单化';
tips[5] = '不会打枪的士兵能打仗么？分不清盐和碱的能成为厨师么？不懂web技术能策划网站么？';
tips[6] = '只有那些符合用户需求的技术才有意义，尊重人比尊重科学更重要，不要迷信“科学”。';
tips[7] = '说服别人之前，先说服自己。每个步骤都要有为什么，弄不明白先去问搜索引擎。';
tips[8] = '策划就是打麻将，搜集是洗牌，整理是码牌，判断是打牌，创新是和牌';
tips[9] = '拿来主义必须建立在理解的基础上，否则思路永远是别人的。';
tips[10] = '闭上眼睛，整个网站都已经在脑海里，这才是开始写方案的时候。';
tips[11] = '书籍是作者思想的渣滓，通过咀嚼作者的渣滓，体会作者嘴里的味道，否则永远是在吃泔水。';
tips[12] = '简单抄袭，必死无疑。';
tips[13] = '网站的三个要素中，内容永远最重要，功能其次，表现在最后。';
tips[14] = '从真实用户角度出发去考虑问题，投资人的意见只能作为参考。';
tips[15] = '真实世界中人们总是不得不被迫接受一些信息；而在网络世界，遇到反感内容，他们往往“关掉浏览器跑掉了”。';
tips[16] = '在追求完美的路上，可能会思考太多，反而让双手闲着。';
tips[17] = '搜索引擎喜欢原创内容和结构合理的Html，而并非罗列出来的关键字。';
tips[18] = '不要小觑用户的智慧，他们能想出各种办法逃脱你设置的条条框框，找到属于他们方式。';
tips[19] = '想让用户在网站上消费更多的时间，就应该用流畅快捷的访问帮助用户节约时间成本。';
tips[20] = '纲要>Word>PPT';
tips[21] = '网页文案要说人话，栏目命名不是楹联游戏，简单明了最重要，押韵对仗是其次。';
tips[22] = '千方百计通过网站营造一种氛围，也许你想传达的“感觉”会成为用户的负担。';
tips[23] = '站的高未必看得远，与其追求鹤立鸡群，不如绕着鸡群走。';
tips[24] = '创意并不是一定要追求与众不同，而是让结果更合理，运作更有效。';
tips[25] = '个人行为与小规模配合压根不需要流程与规范，当交付结果需要大规模的应用时，同一的规格就显得非常重要了。';
tips[26] = '任何创作活动都是为了满足一定的需求，创新是执行过程中的副产品；为了创新而创新，是庸人自扰的行为。';
tips[27] = '“放之四海皆准则”的是真理，真理并不是一种方法，没有一种方法能解决所有的问题；掌握真理，而不是掌握某种方法。';
tips[28] = '在理解的基础上借鉴，就是站在巨人的肩膀之上；没有区分的全盘抄袭，就是被巨人踩在脚下。';
tips[29] = '风险管理对网站非常重要，那些可以预测的闪失往往会造成毁灭性的打击，以史为鉴。';
tips[30] = '别总是强迫他们按照你的思维进行访问，设置“取消”功能往往能够更赢得他们的好感，给用户退路等于给自己退路。';
tips[31] = '“点击”在用户的头脑中是一种确定，“拆散信息”并且“分步引导”比设置臃肿的界面更有效。';
tips[32] = '网站的交互就是屏幕复用：内容逻辑架构是骨骼，内容分块填充是血肉，栅格视觉是肌肤，屏幕复用是动作。';
tips[33] = '技术越来越廉价，必须脚踏实体的为用户提供有效的内容，才能够实现技术的价值。';
tips[34] = '用户有两种，一是实在太闲，以网络打发时间；二是实在太忙，必须借助网络节约时间。';
tips[35] = '网站平台需要具备自发的公平属性，以直接交易和交换为先导，广泛参与，达到普及，这才能算平台。';
tips[36] = '所谓“网站定位”就是实事求是的基于各种现状总结出一个对内容建设、功能规划、服务运营有帮助的指导纲领。';
tips[37] = '不要相信“天下设计一大抄”我们可以借鉴，但绝不能抄袭！';
tips[38] = '学设计，也想学习书法一样，临摹是一个必要的过程。';
tips[39] = '随时用零碎的时间(如等人、排队等)做零碎的事情。';
tips[40] = '学会立体的安排时间。例如：先做饭，再打开收音机，边听广播边洗漱。';
tips[41] = '千万别等到想清楚了再做决定，因为等你什么都想清楚了别人也想清楚了。';
tips[42] = '一个团队的能力不能超出总经理个人能力是可怕的，也是可悲的。——Kevin';
tips[43] = '公司负责人应该是管理专家的专家，抓住大事，放开小事，允许错事，防止坏事。';
tips[44] = '设计有两种方法：一种是简单到明显没有缺陷，另一种复杂到缺陷不那么明显。—— 托尼·霍尔';
tips[45] = '广告创意不要超越大多数人的智商，否则会落得无人问津。';
tips[46] = '没人能拥有所有的答案。身边围绕的天才人物越多，你就越有可能得到一些好答案。';
tips[47] = '坚持读书，要永远走在你周围人的前面，追赶别人和被别人追赶会造就两种不同的气度。';
tips[48] = '靠用户调查来设计产品太难。很多时候，要等到你把产品摆在面前，用户才知道想要什么。——乔布斯';
tips[49] = '显而易见，最高的效率就是对现有材料的最佳利用。';
tips[50] = '学会偷懒，并懒出境界是提高工作效率最有效的方法！';
index = Math.floor(Math.random() * tips.length);
document.writeln(tips[index]);
document.writeln ('&nbsp; <a href="/zt/yulu/" target="_blank">[发表语录]</a>');}
if (code=="lb468x15"){
document.writeln("<script type=\"text\/javascript\"><!--");
document.writeln("google_ad_client = \"ca-pub-4213001413639273\";");
document.writeln("\/* 全站_顶部_468x15 *\/");
document.writeln("google_ad_slot = \"2293322720\";");
document.writeln("google_ad_width = 468;");
document.writeln("google_ad_height = 15;");
document.writeln("\/\/-->");
document.writeln("<\/script>");
document.writeln("<script type=\"text\/javascript\" src=\"http:\/\/pagead2.googlesyndication.com\/pagead\/show_ads.js\"><\/script>");}
if (code=="weibo"){// 微博
document.writeln ('<iframe width="120" height="24" frameborder="0" allowtransparency="true" marginwidth="0" marginheight="0" scrolling="no" border="0" src="http://widget.weibo.com/relationship/followbutton.php?language=zh_cn&width=136&height=24&uid=2556500765&style=2&btn=red&dpc=1"></iframe>');}
if (code=="egg"){// egg
document.write('* 懒人图库承诺：本站所有资源免费下载，无病毒，无弹窗，无干扰链接！ <a href="/plus/guestbook.php">全新改版 提点建议</a>');}
if (code=="jinbu"){// 进步
document.writeln ('<dd>08月13日 设计语录专题上线</dd>');
document.writeln ('<dd>08月05日 网页背景和小图片添加打包下载</dd>');
document.writeln ('<dd>07月12日 修复搜索、导航和返回顶部BUG</dd>');
document.writeln ('<dd>06月26日 改进网页背景频道预览功能</dd>');
//document.writeln ('<dd>06月23日 改进返回顶部功能</dd>');
//document.writeln ('<dd>06月21日 修复IE6下兼容问题</dd>');
//document.writeln ('<dd>06月01日 懒人图库2012新版上线</dd>');
//document.writeln ('<dd>05月26日 新增北方网通服务器</dd>');
//document.writeln ('<dd>05月23日 网页背景改版上线</dd>');
//document.writeln ('<dd>05月20日 网页小图标改版上线</dd>');
document.writeln ('<dd><a href="/about/event.html">...</a></dd>');}
if (code=="tj"){// 统计
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F49542e19848a99b43a81376b929e6c72' type='text/javascript'%3E%3C/script%3E"));

document.writeln ('<script language="javascript" type="text/javascript" src="http://js.users.51.la/2007336.js"></script>');
document.writeln ('<script src="http://s13.cnzz.com/stat.php?id=322926&web_id=322926" language="JavaScript"></script>');
}
if (code=="zan"){// 赞
document.writeln ('<a version="1.0" class="qzOpenerDiv" href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_likeurl" target="_blank">赞</a><script src="http://qzonestyle.gtimg.cn/qzone/app/qzlike/qzopensl.js#jsdate=20111107&style=2&showcount=1&width=100&height=30" charset="utf-8" defer="defer" ></script>');}
if (code=="bdshare"){// 百度分享
document.writeln("<div id=\"bdshare\" class=\"bdshare_t bds_tools_32 get-codes-bdshare\">");
document.writeln("<a class=\"bds_qzone\"><\/a>");
document.writeln("<a class=\"bds_tsina\"><\/a>");
document.writeln("<a class=\"bds_renren\"><\/a>");
document.writeln("<a class=\"bds_tqq\"><\/a>");
document.writeln("<a class=\"bds_baidu\"><\/a>");
document.writeln("<a class=\"bds_qq\"><\/a>");
document.writeln("<a class=\"bds_kaixin001\"><\/a>");
document.writeln("<a class=\"bds_tsohu\"><\/a>");
document.writeln("<a class=\"bds_douban\"><\/a>");
document.writeln("<span class=\"bds_more\">更多<\/span>");
document.writeln("<a class=\"shareCount\"><\/a>");
document.writeln("<\/div>");
document.writeln("<script type=\"text\/javascript\" id=\"bdshare_js\" data=\"type=slide&amp;img=2&amp;uid=12879\" ><\/script>");
document.writeln("<script type=\"text\/javascript\" id=\"bdshell_js\"><\/script>");
document.writeln("<script type=\"text\/javascript\">");
document.writeln("var bds_config = {\"bdTop\":130};");
document.writeln("document.getElementById(\"bdshell_js\").src = \"http:\/\/bdimg.share.baidu.com\/static\/js\/shell_v2.js?t=\" + new Date().getHours();");
document.writeln("<\/script>");}
// 50x50
(function($){$.fn.VMiddleImg=function(options){var defaults={"width":null,"height":null};var opts=$.extend({},defaults,options);return $(this).each(function(){var $this=$(this);var objHeight=$this.height();var objWidth=$this.width();var parentHeight=opts.height||$this.parent().height();var parentWidth=opts.width||$this.parent().width();var ratio=objHeight/objWidth;if(objHeight>parentHeight&&objWidth>parentWidth){if(objHeight>objWidth){$this.width(parentWidth);$this.height(parentWidth*ratio);}else{$this.height(parentHeight);$this.width(parentHeight/ratio);}
objHeight=$this.height();objWidth=$this.width();if(objHeight>objWidth){$this.css("top",(parentHeight-objHeight)/2);}else{$this.css("left");}}
else{if(objWidth>parentWidth){$this.css("left",(parentWidth-objWidth)/2);}
$this.css("top",(parentHeight-objHeight)/2);}});};})(jQuery);$(".f").VMiddleImg();
}
// lazyload

// 搜索
function dysearch()
{
document.writeln("<form name=formsearch onSubmit='return bottomForm();' method=post>");
document.writeln("<div id='x1' class='sa'>");
document.writeln("<a id='s0'>矢量</a>");
document.writeln("<span style='display:none' id='x2' class='lanmu'> ");
document.writeln("<a id=s1>矢量<\/a>");document.writeln("<a id=s2>代码<\/a>");
document.writeln("<a id=s3>图标<\/a>");document.writeln("<a id=s4>表情<\/a>");
document.writeln("<a id=s5>全站<\/a>");document.writeln("<\/span>");document.writeln("<\/div> ");
document.writeln("<input id=\"typeid\" name=\"typeid\" type=\"hidden\" value=\"1\">");
document.writeln("<input id=\"q\" class=sb name=\"keyword\" onFocus=\"if(this.value==\'请输入关键词\'){this.value=\'\';}else{this.select();}this.style.color=\'black\';\"  value=请输入关键词>");
document.writeln("<input class=sc name=Input type=\"submit\" value=\"\">");document.writeln("<\/form>")
	
function $$(id){if(document.getElementById){return document.getElementById(id);}
else if(document.layers){return document.layers[id];}
else{return false;}}
(function(){function initHead(){setTimeout(showSubSearch,0)};function showSubSearch()
{$$("x1").onmouseover=function(){$$("x2").style.display="";$$("x1").className="sa sa_hover"};$$("x1").onmouseout=function(){$$("x2").style.display="none";$$("x1").className="sa"};$$("s1").onclick=function(){selSubSearch(1);$$("q").focus()};$$("s2").onclick=function(){selSubSearch(2);$$("q").focus()};$$("s3").onclick=function(){selSubSearch(3);$$("q").focus()};$$("s4").onclick=function(){selSubSearch(4);$$("q").focus()};$$("s5").onclick=function(){selSubSearch(5);$$("q").focus()};};

function selSubSearch(iType){hbb=[];hbb={1:["矢量","1"],2:["代码","js"],3:["图标","png"],4:["表情","48"],5:["全站","0"]};$$("s0").innerHTML=hbb[iType][0];$$("x2").style.display="none";$$("typeid").value=hbb[iType][1];};initHead();})();
}
function bottomForm()
{	
var all_var=document.getElementById("typeid").value;
var q=document.getElementById("q").value;
switch(all_var)
{case"png": document.formsearch.action='http://www.lanrentuku.com/manager/plus/png.php?type=search&q='+q
break;case"js":document.formsearch.action='http://www.lanrentuku.com/manager/plus/js.php?q='+q
break;
default:
        var Sys = {};
        var ua = navigator.userAgent.toLowerCase();
        var s;
        (s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] :
        (s = ua.match(/firefox\/([\d.]+)/)) ? Sys.firefox = s[1] :
        (s = ua.match(/chrome\/([\d.]+)/)) ? Sys.chrome = s[1] :
        (s = ua.match(/opera.([\d.]+)/)) ? Sys.opera = s[1] :
        (s = ua.match(/version\/([\d.]+).*safari/)) ? Sys.safari = s[1] : 0;       
        if (Sys.ie) {q=encodeURIComponent(q);}//ff
document.formsearch.action='http://www.lanrentuku.com/plus/search.php?x='+all_var+'&q='+q;break;}
document.formsearch.submit();return false;
}

// fav
function addToFavorite(){var a="http://www.lanrentuku.com/";var b="懒人图库";if(document.all){window.external.AddFavorite(a,b)}else if(window.sidebar){window.sidebar.addPanel(b,a,"")}else{alert("亲，您的浏览器不支持此操作\n请直接使用Ctrl+D收藏本站~")}}
// thumb
$(function() {
$('.list-pic img,.list-pngjs img,.list-qq img,.in-box img').hover(function() {
$(this).stop().animate({ "opacity": 0.6 }, 300);
}, function() {
$(this).stop().animate({ "opacity": 1 }, 300);
});
});
// jquery.cookie.min
jQuery.cookie=function(name,value,options){if(typeof value!='undefined'){options=options||{};if(value===null){value='';options.expires=-1;}var expires='';if(options.expires&&(typeof options.expires=='number'||options.expires.toUTCString)){var date;if(typeof options.expires=='number'){date=new Date();date.setTime(date.getTime()+(options.expires*24*60*60*1000));}else{date=options.expires;}expires='; expires='+date.toUTCString();}var path=options.path?'; path='+(options.path):'';var domain=options.domain?'; domain='+(options.domain):'';var secure=options.secure?'; secure':'';document.cookie=[name,'=',encodeURIComponent(value),expires,path,domain,secure].join('');}else{var cookieValue=null;if(document.cookie&&document.cookie!=''){var cookies=document.cookie.split(';');for(var i=0;i<cookies.length;i++){var cookie=jQuery.trim(cookies[i]);if(cookie.substring(0,name.length+1)==(name+'=')){cookieValue=decodeURIComponent(cookie.substring(name.length+1));break;}}}return cookieValue;}};
// fs+bg
var options={path:'/',expires:30};var cookie_fs=$.cookie("fs");var cookie_bg=$.cookie("bg");$(function(){if(cookie_bg){$('#yuedu').css('background',cookie_bg);}
if(cookie_fs){$('#yuedu').css('font-size',cookie_fs+'px');}});function fontsize(num){switch(num){case 1:$("#yuedu").css('font-size','16px');$.cookie("fs","16",options);break;case 2:$("#yuedu").css('font-size','14px');$.cookie("fs","14",options);break;case 3:$("#yuedu").css('font-size','12px');$.cookie("fs","12",options);break;}}
function backcolor(num){if(num==1){$("#yuedu").css('background','#F0F6FC');$.cookie("bg","#F0F6FC",options);}
if(num==2){$("#yuedu").css('background','#FFFFFF');$.cookie("bg","#FFFFFF",options);}
if(num==3){$("#yuedu").css('background','#F6F6F6');$.cookie("bg","#F6F6F6",options);}}
// bg+gif
$(document).ready(function(){$('.content-bg li,.content-gif li').hover(function(){$(".save",this).stop().animate({top:'162px'},{queue:false,duration:162});},function(){$(".save",this).stop().animate({top:'192px'},{queue:false,duration:162});});});
function runSave(){if(saveImg.location!="about:blank")window.saveImg.document.execCommand("SaveAs");}
function saveImgAs(url){if(window.saveImg&&url)window.saveImg.location=url;}
document.writeln('<IFRAME style="DISPLAY: none" onload=runSave() src="about:blank" name=saveImg></IFRAME>');
// tx
function getByid(id) {
	if (document.getElementById) {
		return document.getElementById(id);
	} else if (document.all) {
		return document.all[id];
	} else if (document.layers) {
		return document.layers[id];
	} else {
		return null;
	}
}
function creatID(DivID){
var objs=getByid(DivID).getElementsByTagName('textarea');
var inps=getByid(DivID).getElementsByTagName('input');
var buts=getByid(DivID).getElementsByTagName('button');
var labs=getByid(DivID).getElementsByTagName('label');
	for (i=0; i<objs.length; i++) {
		objs[i].id="runcode"+i;
		inps[i].id=i
		buts[i].id=i
		labs[i].id=i
	}
}
function runCode(obj){
	  var code=getByid("runcode"+obj).value;
	  var newwin=window.open('','','');
	  newwin.opener = null;
	  newwin.document.write(code); 
	  newwin.document.close();
}

function saveCode(obj,title) {
        var winname = window.open('','','');
        winname.document.open('text/html', 'replace');
        winname.document.write(document.getElementById(obj).value);
        winname.document.execCommand('saveas','',title+'.html');
        winname.close();
}
// 焦点图
(function(d,D,v){d.fn.responsiveSlides=function(h){var b=d.extend({auto:!0,speed:1E3,timeout:7E3,pager:!1,nav:!1,random:!1,pause:!1,pauseControls:!1,prevText:"Previous",nextText:"Next",maxwidth:"",controls:"",namespace:"rslides",before:function(){},after:function(){}},h);return this.each(function(){v++;var e=d(this),n,p,i,k,l,m=0,f=e.children(),w=f.size(),q=parseFloat(b.speed),x=parseFloat(b.timeout),r=parseFloat(b.maxwidth),c=b.namespace,g=c+v,y=c+"_nav "+g+"_nav",s=c+"_here",j=g+"_on",z=g+"_s",
o=d("<ul class='"+c+"_tabs "+g+"_tabs' />"),A={"float":"left",position:"relative"},E={"float":"none",position:"absolute"},t=function(a){b.before();f.stop().fadeOut(q,function(){d(this).removeClass(j).css(E)}).eq(a).fadeIn(q,function(){d(this).addClass(j).css(A);b.after();m=a})};b.random&&(f.sort(function(){return Math.round(Math.random())-0.5}),e.empty().append(f));f.each(function(a){this.id=z+a});e.addClass(c+" "+g);h&&h.maxwidth&&e.css("max-width",r);f.hide().eq(0).addClass(j).css(A).show();if(1<
f.size()){if(x<q+100)return;if(b.pager){var u=[];f.each(function(a){a=a+1;u=u+("<li><a href='#' class='"+z+a+"'>"+a+"</a></li>")});o.append(u);l=o.find("a");h.controls?d(b.controls).append(o):e.after(o);n=function(a){l.closest("li").removeClass(s).eq(a).addClass(s)}}b.auto&&(p=function(){k=setInterval(function(){var a=m+1<w?m+1:0;b.pager&&n(a);t(a)},x)},p());i=function(){if(b.auto){clearInterval(k);p()}};b.pause&&e.hover(function(){clearInterval(k)},function(){i()});b.pager&&(l.bind("click",function(a){a.preventDefault();
b.pauseControls||i();a=l.index(this);if(!(m===a||d("."+j+":animated").length)){n(a);t(a)}}).eq(0).closest("li").addClass(s),b.pauseControls&&l.hover(function(){clearInterval(k)},function(){i()}));if(b.nav){c="<a href='#' class='"+y+" prev'>"+b.prevText+"</a><a href='#' class='"+y+" next'>"+b.nextText+"</a>";h.controls?d(b.controls).append(c):e.after(c);var c=d("."+g+"_nav"),B=d("."+g+"_nav.prev");c.bind("click",function(a){a.preventDefault();if(!d("."+j+":animated").length){var c=f.index(d("."+j)),
a=c-1,c=c+1<w?m+1:0;t(d(this)[0]===B[0]?a:c);b.pager&&n(d(this)[0]===B[0]?a:c);b.pauseControls||i()}});b.pauseControls&&c.hover(function(){clearInterval(k)},function(){i()})}}if("undefined"===typeof document.body.style.maxWidth&&h.maxwidth){var C=function(){e.css("width","100%");e.width()>r&&e.css("width",r)};C();d(D).bind("resize",function(){C()})}})}})(jQuery,this,0);
$(function() {
    $(".f426x240").responsiveSlides({
        auto: true,
        pager: true,
        nav: true,
        speed: 700,
        maxwidth:1024
    });
    $(".f160x160").responsiveSlides({
        auto: true,
        pager: true,
        speed: 700,
        maxwidth: 160
    });
});
