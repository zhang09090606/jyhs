<?php
include("includes/init.php");
if(empty($_SESSION['name'])){
    $Db->back_info("请您先登录","login.php");
}
$name=$_SESSION['name'];		
$row = $Db->get_one("user","name='$name'");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<link href="css/my.css" rel="stylesheet" type="text/css" />
<script src="js/jquery-1.9.1.min.js"></script>
<script src="js/my.js" type="text/javascript"></script>
<title>我的</title>
</head>
<body>
	<div class="head" align="center"><font color="#FFFFFF" size="+2">我的</font></div>
	<div class="div1">
		<img src="images/head.png" class="div1_image">
		<span class="div1_font"><?php echo $row['nickname'];?></span></font>
	</div>
	<hr color="#EAEAEA" size="4px">
	<div class="div2">
		<img src="images/dingdan.png" width="40px" height="40px">
		<p class="div2_p">废品订单</p>
		<div class="div_div">
			<p class="div_div_p">查看所有订单</p>
			<img src="images/arrow.png" class="div_div_img">
		</div>
	</div>
	<hr color="#EAEAEA" size="1px">
	<div class="div3">
				<li>
					<ul><center><img src="images/issumit.png"></center></ul>	
					<ul><center><img src="images/qiangdan.png"></center></ul>	
					<ul><center><img src="images/recovery.png"></center></ul>	
				</li>
	</div>
	<hr color="#EAEAEA" size="4px">
	<div class="div4">
		<img src="images/balloon.png" class="div4_img">
		<p class="div4_p">绿化值商城</p>
		<img src="images/arrow.png" class="div_div_img">
	</div>
	<hr color="#EAEAEA" size="1px">
	<div class="div5">
		<img src="images/add.png" class="div5_img">
		<p class="div5_p">我的地址</p>
		<img src="images/arrow.png" class="div_div_img">
	</div>
	<hr color="#EAEAEA" size="4px">
	<div class="div6">
		<img src="images/erweima.png" class="div6_img">
		<p class="div6_p">分享二维码</p>
		<img src="images/arrow.png" class="div_div_img">
	</div>
	<hr color="#EAEAEA" size="1px">
	<div class="div7">
		<img src="images/share.png" class="div7_img">
		<p class="div7_p">分享给朋友</p>
		<img src="images/arrow.png" class="div_div_img">
	</div>
	<div class="botten_div">
		<table class="botten_table">
			<tr><td  align="center" id="pic1"><img src="images/20180216144524.png" id="p1"></td>
				<td  align="center" id="pic2"><img src="images/20180216182009.png" id="p2"></td>
				<td  align="center" id="pic3"><img src="images/20180216144549.png" id="p3"></td>
				<td  align="center" id="pic4"><img src="images/20180216144607.png" id="p4"></td>
			</tr>
		</table>
		
	</div>
</body>
</html>
